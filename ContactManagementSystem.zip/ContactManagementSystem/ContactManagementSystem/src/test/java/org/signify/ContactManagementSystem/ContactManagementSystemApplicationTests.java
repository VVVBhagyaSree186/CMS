package org.signify.ContactManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
